%% ���⣺�ۺϸ���ģ�ͣ�CLM������    
% written by �󺭱� Hanbin Diao
%% ���ò���ʱ�κͲ�������
Tstrat=1;
Tend=5;
Th=0.01;
%%
tpoinset=Tstrat:Th:Tend; 
SampletimeSet=zeros(1,size(tpoinset,2));
SEdqSet_measurement=[s,Emd,Emq];
Data=[V_Vth_measurement.time, V_Vth_measurement.signals(1).values,...
    P_Q_measurement.signals(1).values, P_Q_measurement.signals(2).values,...
    V_Vth_measurement.signals(2).values,f_measurement.signals.values];
for n=1:size(tpoinset,2)
SampletimeSet(n)=find(abs(Data(:,1)-tpoinset(n))<=1e-8);
end

DataCLM=Data(SampletimeSet,:);
DataCLM(:,1)=0:Th:(Tend-Tstrat);
DataCLM(:,3:4)=DataCLM(:,3:4)/1e8;
SEdqSetCLM_measurement=SEdqSet_measurement(SampletimeSet,:);